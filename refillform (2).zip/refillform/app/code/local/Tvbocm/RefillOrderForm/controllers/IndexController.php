<?php
class Tvbocm_RefillOrderForm_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
		//die("adsjhsdvzx");
		$this->loadLayout();     
		$this->renderLayout();
		
    }
	
	public function postAction()
    {
        $post = $this->getRequest()->getPost();
		
		if ($post) {
		try {
			$fullname=$post['fullname'];
			$cemail=$post['email'];
			$orderid=$post['orderid'];
			$medicineRadio=$post['medicineRadio'];
			
			if($medicineRadio == "No"){
			$orderchanges=$post['orderchanges'];
			}
			else {
			$post['orderchanges']='Same Medicine';
			}
			
			
			$billingRadio=$post['billingRadio'];
			
			if($billingRadio == "No"){
			$billingChanges=$post['billingChanges'];
			}
			else {
			$post['billingChanges']='Same Billing Address';
			}
			
			$shippingRadio=$post['shippingRadio'];
			
			if($shippingRadio == "No"){
			$shippingChanges=$post['shippingChanges'];
			}
			else {
			$post['shippingChanges']='Same Shipping Address';
			}
			
			$paymentRadio=$post['paymentRadio'];
			if($paymentRadio == "No"){
			$paymentChanges=$post['paymentChanges'];
			}
			else {
			$post['paymentChanges']='Same Payment Method';
			}
			
			
			$postObject = new Varien_Object();
			$postObject->setData($post);
			
			
			$storeId = Mage::app()->getStore()->getId();
					
					$emailTemplate = 1;
					
					//get store config value
					$mailSubject = 'Customer Order Refill';
					
					$sender = array('name' => $fullname, 'email' => $cemail);
					 
					$translate = Mage::getSingleton('core/translate');
					$emailArray =array('tech@offshorecheapmeds.co');
					
					foreach ($emailArray as $email) {

						$translate->setTranslateInline(false);
						Mage::getModel('core/email_template')
								->setDesignConfig(array('area' => 'frontend', 'store' => $storeId))
								->setTemplateSubject($mailSubject)
								->sendTransactional(
										$emailTemplate, $sender, $email, '', array('data' => $postObject));
						$translate->setTranslateInline(true);
					}
					Mage::getSingleton('core/session')->addSuccess('Your order has been received!');
                
                $this->_redirectUrl('*/*/');
				//$this->_redirectUrl('refillorder');

                return;
            } catch (Exception $e) {
                $translate->setTranslateInline(true);

                Mage::getSingleton('core/session')->addError('Somthing went wrong, Please contact to Er. Ranjeet..!');
                $this->_redirect('*/*/');
                return;
            }

        } else {
            $this->_redirect('*/*/');
        }
	
	}
	

    }