var mysql = require('mysql');
var express = require('express');
var app = express();

app.use(express.static('public'));
app.get('/' ,function(req,res){
	res.sendFile(__dirname + "/" + "login.html")
});
app.get('/success',function(req,res){
	res.sendFile(__dirname + "/" + "success.html")
});

app.get('/dashboard',function(req,res){
	res.sendFile(__dirname + "/" + "dashboard.html" )
})

app.get('/login',function(req,res){
	// Prepare out put in JSON format

	//response = {
		userName = req.query.userName,
		password = req.query.password
	//}
	//console.log(response);
	//res.redirect("/success");

/*******************Create Database Connection ************/

var con = mysql.createConnection({
	host:'localhost',
	user:'root',
	password:'',
	database:'nodejs'
})

con.connect(function(err){
	if(err){
		throw err;
	}else{
		console.log("Connection with mysql is successful.");
		var sql = "SELECT * FROM users";
		con.query(sql,function(err,result,fields){
			if(err){
				throw err;
			}else{
				//console.log(result);
				//console.log(fields);
				if(result.length == 0){
					console.log("No Record Found");
				}else{
					for(i=0;i<result.length;i++){
						dbUserName = result[i].uname;
						dbPassword = result[i].upassword;
						//console.log(dbUserName);
						//console.log(dbPassword);
					}

					if((userName == dbUserName) && (password == dbPassword)){
						console.log("Hey your login is successfull.!");
						console.log("You are redirected to the dashboard");
						res.redirect("/dashboard");

					}else{
						console.log("Login Failed..!");
						res.redirect("/");
					}
				}
			}
		});
	}
});

})
var server = app.listen(8080,function(req,res){
	console.log("Server is listening at http://localhost:8080/");
});