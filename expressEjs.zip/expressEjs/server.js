

var mysql = require('mysql');
var express = require('express');
var session = require('express-session');
var mysqlDbConnection = require('./mysqlDbConnection');
var app = express();


var bodyParser = require('body-parser');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true })); 

app.use(express.static('public'));
app.use(session({secret : 'ssshhh'}));

app.set('view engine', 'ejs');
app.set('views','./views');

var userSession;

app.get('/' , function(req,res){
	userSession = req.session;
	if(userSession.userName){
		console.log("Checking user session for user Name::::" + userSession.userName);
		res.render('pages/dashboard', {user:userSession.userName, title:'Product Management s/m'});
	}else{
		res.render("pages/login")
	}
	
});
app.get('/success',function(req,res){
	res.render("pages/success")
});

app.get('/dashboard',function(req,res){
	userSession = req.session;
	res.render( 'pages/dashboard', {title:'Dashboard'});
});

app.get('/loginfailed', function(req,res){
	res.render("pages/login_failed" )
});

/*********************Start User Login***********************/

app.post('/login', function(req,res){
			// Prepare out put in JSON format
			userSession = req.session;

			//response = {
				userSession.userName = req.body.userName;
				password = req.body.password;

				//console.log("Username is:" + userName + " "+ "User password is :" + password);
			//}
			//console.log(response);
			//res.redirect("/success");
		var con = mysqlDbConnection.dbConnection();
		con.connect(function(err){
			if(err){
				throw err;
			}
			console.log("Connection with mysql is successful.");
			var sql = "SELECT * FROM users where uname ='" + userSession.userName + "' &&  upassword ='" + password + "' ;"
			//console.log(sql);
			con.query(sql,function(err,result,fields){
				//console.log(result);
				if(err){
					throw err;
				}
				console.log("Query Executed successfully.!");
				console.log(result);
				if(result.length >= 1){
				console.log("Hey your login is successfull.!");
				console.log("You are redirected to the dashboard");
				//res.send("Welcome " + userName);
				user = userSession.userName;
				console.log("Checking user session in user Name::::" + user);
				res.render("pages/dashboard", {user,title:'Product Management System'});
				
				}else{
					console.log("Your user name password not matched");
					res.redirect('loginfailed');

					}
				});

		});
});

/*****************************Start user Login failed*******************/

app.get('/login_failed', function(req,res){
	res.render("pages/login_failed")
});

app.get('/forgetpasswordrequest', function(req,res){
	res.setHeader('Content-Type','text/plain');
	userName = req.query.userName;
	
	var con = mysqlDbConnection.dbConnection();
	con.connect(function(err){
		if(err){
			throw err;
		}else
		console.log('You have connected with mysql database for password retreive');
		var sql = "select * from users where uname ='" + userName + "' ";
		console.log(sql);
		
		con.query(sql,function(err,result,fields){
			if(err){
				throw err;
			}

			console.log(result);
			
			//console.log(result.length);
			if(result.length >= 1){

				console.log("Your Username has matched");
				
				//res.redirect('/getusername');
				//res.writeHead(200,{'content-Type':'text/html'});
				res.send( "Your User Name is: " + result[0].uname + " " + " " + "Your Password is: " + result[0].upassword );
				//res.end();
			}
			else{
				console.log("User Name does exists. Please create account.");
				res.redirect('/registerHere');
				
				}
			
		});
	});
});

/*****************************End user Login failed*******************/
/**********************User Registration Start************************/

app.get('/registerHere', function(req,res){
	res.render("pages/registerHere");
});

app.post('/userRegistration', function(req,res){
	res.setHeader('content-Type','text/html');

	userName = req.body.username;
	userpass = req.body.password;

	var con = mysqlDbConnection.dbConnection();
	con.connect(function(err){
		if(err){
			throw err;
		}else{
			console.log("Your connection is successful once again for user registration");
			var sql = "INSERT INTO users(uname,upassword) values('" +userName+ "','" +userpass+ "');"
			console.log(sql);
			con.query(sql,function(err,result,fields){
				if(err){
					throw err;
				}else{
					console.log(result);
					console.log(fields);
					res.send('<html>'
						    + '<h3> Hi ' + userName + " " +"Your Registration is successful !" + '</h3>'
						    + '</html>');
				}
			});
		}
	});
});

/***********************End User Registration*******************************/

/***********************Start reset password section************************/
app.post('/resetPassword', function(req,res){
	res.setHeader('content-Type','text/html');

	userName = req.body.username;
	password = req.body.password;
	rePassword = req.body.repassword;
	console.log("Your user Name is :" + userName + " " + "Your pass is: " + password + " " + "Your Re-Enter password is :" + rePassword);
	var con =  mysqlDbConnection.dbConnection();
	con.connect(function(err){
		if(err){
			throw err;
		}else{
			console.log("Your connection with my SQL is successful, Now you can fire your queries from here!");
			var sql = "SELECT * from users where uname = '" +userName+ "' ;"
			console.log(sql);
			con.query(sql,function(err,result,fields){
				if(err){
					throw err;
				}else{
					console.log(result);
					if(result.length >=1){
						var sql = "UPDATE users set upassword ='" +password+ "' where uname ='" +userName+ "' ;"
						console.log("Sql for update user Password: " + sql);
						con.query(sql,function(err,result,fields){
							if(err){
								throw err;
							}else{
								console.log(result);
								console.log(fields);
								console.log("Your password has been updated successfully.!");
								var sql = "Select * from users where uname = '" + userName + "';"
								console.log(sql);
								con.query(sql,function(err,result,fields){
									if(err){
										throw err;
									}else{
										console.log(result);
										console.log(fields);
										res.write("Hey your password has been updated successfully." + " " + "For the user name : " + userName + " " + "Your password is :" + result[0].upassword);
									}
								});
								
							}
						});
					}else{
						console.log("User name does not exists");
						res.redirect('/login_failed');
					}
				}
			});
		}
	});
	
});
/***********************End reset password section*************************/

/***********************Start Add Product section**************************/

app.get('/addproduct',function(req,res){
	userSession = req.session;
	console.log("Testing for user name in ADD PRODUCT PAGE::" + userSession.userName);
	res.render("pages/addProduct", {user:userSession.userName, title:'Add Product'} )

});

app.post('/addproductRequest',function(req, res){
	res.setHeader('Content-Type', 'text/plain');

	productCategory = req.body.productCategory,
	productManufacturer = req.body.productManufacturer,
	productDescription = req.body.productDescription,
	productCost = req.body.productCost,
	productQuantity = req.body.productQuantity;
	productSpecification = req.body.productSpecification
	
	/***************Connection with database Start**********************/
	var con = mysqlDbConnection.dbConnection();
	con.connect(function(err){
		if(err){
			throw err;
		}else{
			console.log("Mysql connection is successful for add product.!");
			//res.redirect("/success");
			//create table products(product_id int not null auto_increment primary key,productCategory varchar(20),productManufacturer varchar(20),
			//productDescription varchar(20),productCost varchar(20),productQuantity varchar(20),productOtherSpecifiaction varchar(50));
			var sql = "insert into products (productCategory,productManufacturer,productDescription,productCost,productQuantity,productOtherSpecifiaction) values('"+productCategory+"','"+productManufacturer+"','"+productDescription+"','"+productCost+"','"+productQuantity+"','"+productSpecification+"')";
			console.log(sql);
			con.query(sql, function(err,result,fields){
				if(err){
					throw err;
				}else{
					console.log("Product Has been added successfully");
					res.redirect("/dashboard");
				}
			})
		}
	})
})

/***********************Start Retreive Product section**************************/
app.get('/retreiveProduct', function(req,res){
	userSession = req.session;
	var con = mysqlDbConnection.dbConnection();
	con.connect(function(err){
		if(err){
			throw err;
		}else{
			console.log("Mysql database connection is successful for retreive products");
			var sql = "select * from products;"
			console.log("Check SQL query::" + sql);
			con.query(sql, function(err, result, fields){
				if(err){
					throw err;
				}else{
					if(result.length == 0){
						console.log("No data Found");
						res.render("pages/addproduct", {title:'Add Product',user:userSession.userName});
					}else{
						console.log("Showing length "+ result.length);
						console.log("Showing all results from the CUSTOMERS:: " + result);
						// for(i=0;i>=result.length;i++){
						// 	productString1 = "<tr><td>" + " " + result[i].productCategory + " " + "</td><td>" + " " + result[i].productManufacturer + "</td></tr>" ;
						// 	res.render(productString1);
						results = result;
						res.render('pages/retreiveProduct', {user:userSession.userName,title:'Dashboard',results: results})	
						}

						
					}
				
			});
		}
	});
	//res.render('pages/retreiveProduct', {user:userSession.userName,title:'All Products'})

});
/***********************End Retreive Product section****************************/


/***********************End Add Product section**************************/

app.get('/getusername', function(req,res){
	res.render("pages/userGetRequest");
});


/*****************************Start user Logout***************************/
app.get('/logout' , function(req,res){
	userSession = req.session;
	req.session.destroy(function(err){
		if(err){
			throw err;
		}else{
			console.log("Session is destroyed, You are redirected to the login page.");
			res.redirect('/');
		}
	});

});
/*****************************End User Logout*****************************/


var server = app.listen(8080, function(req,res){
	console.log("Server is listening at http://localhost:8080/");
});