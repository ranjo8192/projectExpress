<?php
class Tvbocm_Refillform_Block_Refillform extends Mage_Core_Block_Template
{
	public function _prepareLayout(){
		return parent::_prepareLayout();
	}
}
?>