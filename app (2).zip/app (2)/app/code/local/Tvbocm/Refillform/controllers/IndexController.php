<?php
class Tvbocm_Refillform_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
		$this->loadLayout();     
		$this->renderLayout();
    }
	
	public function postAction()
    {
        $post = $this->getRequest()->getPost();
		if ($post) {
		try {
			$cname=$post['fullname'];
			$cemail=$post['email'];
			$cphone=$post['phone'];
			$cfax=$post['fax'];
			$cproduct1=$post['product_description_product1'];
			$cprodqty1=$post['product_description_qty1'];
			$cproduct2=$post['product_description_product2'];
			$cprodqty2=$post['product_description_qty2'];
			$cproduct3=$post['product_description_product3'];
			$cprodqty3=$post['product_description_qty3'];
			if(!empty($post['product_description_product4'])){
			$cproduct4=$post['product_description_product4'];}
			if(!empty($post['product_description_qty4'])){
			$cprodqty4=$post['product_description_qty4'];}
			if(!empty($post['product_description_product5'])){
			$cproduct5=$post['product_description_product5'];}
			if(!empty($post['product_description_qty5'])){
			$cprodqty5=$post['product_description_qty5'];}
			$ccomment=$post['comment'];
			
			$postObject = new Varien_Object();
			$postObject->setData($post);
			
			
			$storeId = Mage::app()->getStore()->getId();
					
					$emailTemplate = 1;
					
					//get store config value
					$mailSubject = 'Refill Enquiry';
					
					$sender = array('name' => $cname, 'email' => $cemail);
					 
					$translate = Mage::getSingleton('core/translate');
					$emailArray =array('tech@offshorecheapmeds.co');
					
					foreach ($emailArray as $email) {

						$translate->setTranslateInline(false);
						Mage::getModel('core/email_template')
								->setDesignConfig(array('area' => 'frontend', 'store' => $storeId))
								->setTemplateSubject($mailSubject)
								->sendTransactional(
										$emailTemplate, $sender, $email, '', array('data' => $postObject));
						$translate->setTranslateInline(true);
					}
					Mage::getSingleton('customer/session')->addSuccess('Your refill inquiry was submitted! Thank you for contacting us.');
                
                $this->_redirectUrl('*/*/');

                return;
            } catch (Exception $e) {
                $translate->setTranslateInline(true);

                Mage::getSingleton('customer/session')->addError('Unable to submit your request. Please, try again later');
                $this->_redirect('*/*/');
                return;
            }

        } else {
            $this->_redirect('*/*/');
        }
	
	}
	

    }